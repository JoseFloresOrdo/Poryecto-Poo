public class ConversionesGastos{

    public int ConversionEnergia(GastoEnergía energia){
        int kilowatts=0;
        return kilowatts;
    }
    
    public int ConversionAgua(GastoAgua agua){
        int litros=0;
        return litros;
    }

    public int ConversionGasolina(GastoGasolina gasolina){
        int galones=0;
        return galones;
    }

}